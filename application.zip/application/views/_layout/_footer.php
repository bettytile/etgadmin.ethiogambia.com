<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
		Ethio-Gambia
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2020 <a href="#">Ethio-Gambia</a>.</strong> All rights reserved.
</footer>