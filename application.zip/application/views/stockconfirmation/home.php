<div class="msg" style="display:none;">
  <?php echo @$this->session->flashdata('msg'); ?>
</div>

<div class="box">
  <div class="box-header">
  
  </div>
  <!-- /.box-header -->
  <div class="box-body">
    <table id="list-data" class="table table-bordered table-striped">
      <thead>
        <tr>
          <th >Product Code</th>
          <th >Reference NO</th>
          <th >Received QTY</th>
          <th >Issued QTY</th>
          <th >Station</th>
          <th >Activity Date</th>
          
          <th style="text-align: center;">Manage</th>
        </tr>
      </thead>
      <tbody id="data-confirm" >
      <?php
        foreach ($dataStock as $pegawai) {
          ?>
          <tr>
            <td ><?php echo $pegawai->code; ?></td>
            <td><?php echo $pegawai->reference_no; ?></td>
            <td ><?php echo $pegawai->received_qty; ?></td>
            <td ><?php echo $pegawai->issued_qty; ?></td>
            <td><?php echo $pegawai->station; ?></td>
            <td><?php echo $pegawai->activity_date; ?></td>
            
            <td class="text-center col-sm-12" style="min-width:200px;">
               <button class="btn btn-success btn-sm confirm-product" data-id="<?php echo $pegawai->id; ?>" data-toggle="modal" data-target="#confirmProduct"><i class="glyphicon glyphicon-check"></i>  Confirm</button> 
              <button class="btn btn-warning btn-sm update-datastockProduction" data-id="<?php echo $pegawai->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Update</button>
              <button class="btn btn-danger btn-sm delete-product" data-id="<?php echo $pegawai->id; ?>" data-toggle="modal" data-target="#deleteProduct"><i class="glyphicon glyphicon-remove-sign"></i>  Delete</button>
            </td>
          </tr>
          <?php
        }
?>
      </tbody>
    </table>
  </div>
</div>


<div id="tempat-modal"></div>

 <?php show_my_confirm('deleteProduct', 'hapus-dataProduction', 'Do You Want To Delete?', 'yes'); ?> 
<?php show_my_confirm('confirmProduct', 'hapus-dataConfirmation', 'Do You Want To confirm?', 'ok'); ?>

<?php
  $data['judul'] = 'Confirmation';
  $data['url'] = 'Confirmation/import';
  echo show_my_modal('modals/modal_import', 'import-production', $data);
?>