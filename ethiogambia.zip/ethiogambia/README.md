# AdminLTE-CRUD-With-Codeigniter
CRUD dengan Template Admin LTE menggunakan Codeigniter

Fitur : 
  1. CRUD with Ajax
  2. Datatable
  3. Export dan Import ke Excel
  4. Chart
  
Akun Login :
  1. username : auwfar / password : auwfar
  2. username : ozil / password : ozil
$P$BEw1u254yQql8QTdh/6X3iwWYtKfs5/ my
$P$BPgB7AJLUswXu96jRYbXyVl6nnYW6w/