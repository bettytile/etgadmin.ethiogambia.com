<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_confirmation extends CI_Model {
	public function select_all_production() {
		$sql = "SELECT * FROM production WHERE production.confirmation_status='0'";

		$data = $this->db->query($sql);

		return $data->result();
	}

	public function select_all() {
		$sql = " SELECT production.production_id AS id, production.id_production_type AS production_type, production_type.production_type_name AS production_type, 
        production.reference_no AS reference_no, production.id_employee AS employee, employees.employee_name AS employee, 
        production.shift AS shift, production.id_machine AS machine, machine.machine_name AS machine, machine.machine_code AS machine, production.id_product AS code, product.product_code AS code, production.id_preform AS preform, product.product_code AS preform,production.qty_produced AS qty_produced,production.qty_damaged AS qty_damaged, 
        production.activity_date AS activity_date,production.confirmation_status AS confirmation_status, 
        production.id_station AS station, station.station_name AS station, production.id_raw_material AS raw_material, 
        production.received_weight AS received_weight,production.left_weight AS left_weight, production.used_weight AS used_weight,production.damaged_weight AS damaged_weight,
		production.differences AS differences, production.overall_weight AS overall_weight,production.edit_status AS edit_status, 
        production.edit_date AS edit_date,production.editor_name AS editor_name FROM production,product,station,
        production_type, employees, machine WHERE production.id_production_type = production_type.production_type_id 
        AND production.id_product = product.prod_id AND production.id_employee = employees.employee_name AND production.id_machine = machine.mach_id AND production.id_station = station.s_id AND production.confirmation_status='0'";
		$data = $this->db->query($sql);

		return $data->result();
	}
	public function select_all_inproduction() {
		$sql = " SELECT production.production_id AS id, production.id_production_type AS production_type, production_type.production_type_name AS production_type, 
        production.reference_no AS reference_no, production.id_employee AS employee, employees.employee_name AS employee, 
        production.shift AS shift, production.id_machine AS machine, machine.machine_name AS machine, machine.machine_code AS machine, production.id_product AS code, product.product_code AS code, production.id_preform AS preform, product.product_code AS preform,production.qty_produced AS qty_produced,production.qty_damaged AS qty_damaged, 
        production.activity_date AS activity_date,production.confirmation_status AS confirmation_status, 
        production.id_station AS station, station.station_name AS station, production.id_raw_material AS raw_material, 
        production.received_weight AS received_weight,production.left_weight AS left_weight, production.used_weight AS used_weight,production.damaged_weight AS damaged_weight,
		production.differences AS differences, production.overall_weight AS overall_weight,production.edit_status AS edit_status, 
        production.edit_date AS edit_date,production.editor_name AS editor_name FROM production,product,station,
        production_type, employees, machine WHERE production.id_production_type = production_type.production_type_id 
        AND production.id_product = product.prod_id AND production.id_employee = employees.employee_name AND production.id_machine = machine.mach_id AND production.id_station = station.s_id";
		$data = $this->db->query($sql);

		return $data->result();
	}

	public function select_by_id($id) {
	$sql = "SELECT production.production_id AS id, production.id_production_type AS id_production_type, production_type.production_type_name AS production_type, 
    production.reference_no AS reference_no, production.id_employee AS employee, employees.employee_name AS employee, 
    production.shift AS shift, production.id_machine AS id_machine, machine.machine_name AS machine, machine.machine_code AS machine, production.id_product AS id_product, product.product_code AS code, production.id_preform AS id_preform, product.product_code AS product_code,production.qty_produced AS qty_produced,production.qty_damaged AS qty_damaged, 
    production.activity_date AS activity_date,production.confirmation_status AS confirmation_status, 
    production.id_station AS id_station, station.station_name AS station, production.id_raw_material AS raw_material, 
    production.received_weight AS received_weight,production.left_weight AS left_weight, production.used_weight AS used_weight,production.damaged_weight AS damaged_weight,
	production.differences AS differences, production.overall_weight AS overall_weight,production.edit_status AS edit_status, 
    production.edit_date AS edit_date,production.editor_name AS editor_name FROM product, production, station,
    production_type, employees, machine WHERE production.id_production_type = production_type.production_type_id 
    AND production.id_product = product.prod_id AND production.id_employee = employees.employee_name AND production.id_machine = machine.mach_id AND production.id_station = station.s_id AND production.production_id= {$id}";
		// $sql = "SELECT pegawai.id AS id_pegawai, pegawai.nama AS nama_pegawai, pegawai.id_kota, pegawai.id_kelamin, pegawai.id_posisi, pegawai.telp AS telp, kota.nama AS kota, kelamin.nama AS kelamin, posisi.nama AS posisi FROM pegawai, kota, kelamin, posisi WHERE pegawai.id_kota = kota.id AND pegawai.id_kelamin = kelamin.id AND pegawai.id_posisi = posisi.id AND pegawai.id = '{$id}'";

		$data = $this->db->query($sql);

		return $data->row();
	}
	public function select_all_rawmaterial() {
		$sql = " SELECT product.prod_id AS id, product.product_code AS code, product.product_weight AS p_weight, product.id_type AS p_type, product_type.product_name AS p_type FROM product, product_type WHERE product.id_type = product_type.p_id AND product_type.product_name='Raw Material'";
		$data = $this->db->query($sql);

		return $data->result();
	}

	
	public function update($data) {
				
		$p_code_n_id = $data['id_product'];
		$resultexp = explode('|',$p_code_n_id);
		$id_products = $resultexp[1];
		
		$m_code_n_id = $data['id_machine'];
		$resultexpmchn = explode('|',$m_code_n_id);
		$machine = $resultexpmchn[1];
		
		$pre_code_n_id = $data['id_preform'];
		$resultexppre = explode('|',$pre_code_n_id);
		$preform = $resultexppre[1];
		
		$p_type_n_id = $data['production_type'];
		
		
		$sql = "UPDATE production SET id_production_type='$p_type_n_id', reference_no='" .$data['reference_no'] ."', id_employee='" .$data['id_employee'] ."',
		shift='" .$data['shift'] ."', id_machine='$machine', id_product='$id_products',
		id_preform='$preform', qty_produced='" .$data['qty_produced'] ."', qty_damaged='" .$data['qty_damaged'] ."',
		activity_date='" .$data['activity_date'] ."', id_station='" .$data['id_station'] ."', id_raw_material='" .$data['raw_material'] ."',
		received_weight='" .$data['received_weight'] ."', left_weight='" .$data['left_weight'] ."', confirmation_status='1' WHERE production_id='" .$data['id'] ."'";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}
	public function delete($id) {
		$sql = "DELETE FROM production WHERE production_id='" .$id ."'";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function insertStock($data) {
		// $id = md5(DATE('ymdhms').rand());
		$p_code_n_id = $data['id_product'];
		$resultexp = explode('|',$p_code_n_id);
		$id_products = $resultexp[1];
		$con = mysqli_connect("localhost","root","","cendana") or die("Connection could not be Established");
		$select = "SELECT * FROM stock WHERE stock.id_product='" .$id_products ."'";
		$run = mysqli_query($con,$select);
  		$row= mysqli_fetch_array($run);
		
		$activity_date = DATE('ymdhms');
		
		$previous_qty = $row['available_product'];
		
		$qty_produced = $data['qty_produced'];
		$received_qty= $row['received_qty'];
		$re_total = $received_qty + $qty_produced;
		$total = $previous_qty + $qty_produced;
		if ($row > 0) {
			$sqlU = "UPDATE stock SET available_product = '$total', received_qty='$re_total', activity_date='$activity_date'  WHERE stock.id_product ='".$id_products."' AND stock.station = '" .$data['id_station'] ."'";

			$this->db->query($sqlU);
		}
		else {
			$sql = "INSERT INTO stock (id_product,product_type,available_product,received_qty,station,activity_date,s_status) VALUES
			('$id_products','" .$data['production_type'] ."','" .$data['qty_produced'] ."','" .$data['qty_produced'] ."','" .$data['id_station'] ."','$activity_date','received')";

			$this->db->query($sql);

		}

        
		return $this->db->affected_rows();
	}
	public function updateStoke($id) {
		//$id = $_POST['id'];
		$con = mysqli_connect("localhost","root","","cendana") or die("Connection could not be Established");
		$select = "SELECT * FROM production WHERE production_id ='" .$id ."'";
		//$sel = "SELECT * FROM stock WHERE stock.id_product = production.id product";
		$run = mysqli_query($con,$select);
		$row=mysqli_fetch_array($run);
		//$runn = mysqli_query($con,$sel);
  		//$check=mysqli_fetch_array($runn);
		$id =$row['production_id'];
		$activity_date = DATE('ymdhms');
		$id_product = $row['id_product'];
		$id_station = $row['id_station'];
		$production_type = $row['id_production_type'];
		$qty_produced = $row['qty_produced'];
		
		if ($row > 0) {
			$sel = "SELECT * FROM stock WHERE id_product = '$id_product' AND station ='$id_station'";
			$run = mysqli_query($con,$sel);
			$rowi=mysqli_fetch_array($run);
			$available_product = $rowi['available_product'];
			$received_qty = $rowi['received_qty'];
			$upd_receive = $qty_produced + $received_qty;
			$total= $qty_produced + $available_product;
			if($rowi > 0) {
			$sqlU = "UPDATE stock SET available_product = '$total',received_qty = '$upd_receive' WHERE id_product = '$id_product' AND station ='$id_station'";
			$this->db->query($sqlU);
		}
		}
		else {
			$sql = "INSERT INTO stock (id_product,product_type,available_product,received_qty,station,activity_date,s_status) VALUES
			('$id_product','$production_type','$total','$qty_produced','$id_station','$activity_date','received')";

			$this->db->query($sql);

		}

		return $this->db->affected_rows();
	}
	public function directUpdate($id) {
		$sql = "UPDATE production SET confirmation_status='1' WHERE production_id ='" .$id ."'";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}
	public function insert_batch($data) {
		$this->db->insert_batch('production', $data);
		
		return $this->db->affected_rows();
	}

	public function check_name($code,$name,$activty_date,$produced,$damaged) {
		$this->db->where('id_product', $code);
		$this->db->where('id_employee', $name);
		$this->db->where('activity_date', $activty_date);
		$this->db->where('qty_produced', $produced);
		$this->db->where('qty_damaged', $damaged);
		$data = $this->db->get('production');

		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('production');

		return $data->num_rows();
	}
}

/* End of file M_pegawai.php */
/* Location: ./application/models/M_pegawai.php */