<div class="content-wrapper">
  <!-- headerContent -->
  <?php echo @$_headerContent; ?>
  

  <!-- Main content -->
  <section class="content">
    <?php echo @$_mainContent; ?>
  </section>
</div>